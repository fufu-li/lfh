package cn.estore.Test;

import cn.estore.entity.CustomerEntity;

public class TestPassword {
	public static void main(String[] args) {
		CustomerEntity customerEntity = new CustomerEntity(100,"w2","123456");
		
		
		
				
	}
}
